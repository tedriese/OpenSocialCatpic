/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['\u043f. \u043d. \u0435.', '\u043d. \u0435'],
  ERANAMES: ['\u041f\u0440\u0435 \u043d\u043e\u0432\u0435 \u0435\u0440\u0435', '\u041d\u043e\u0432\u0435 \u0435\u0440\u0435'],
  NARROWMONTHS: ['\u0458', '\u0444', '\u043c', '\u0430', '\u043c', '\u0458', '\u0458', '\u0430', '\u0441', '\u043e', '\u043d', '\u0434'],
  MONTHS: ['\u0458\u0430\u043d\u0443\u0430\u0440', '\u0444\u0435\u0431\u0440\u0443\u0430\u0440', '\u043c\u0430\u0440\u0442', '\u0430\u043f\u0440\u0438\u043b', '\u043c\u0430\u0458', '\u0458\u0443\u043d', '\u0458\u0443\u043b', '\u0430\u0432\u0433\u0443\u0441\u0442', '\u0441\u0435\u043f\u0442\u0435\u043c\u0431\u0430\u0440', '\u043e\u043a\u0442\u043e\u0431\u0430\u0440', '\u043d\u043e\u0432\u0435\u043c\u0431\u0430\u0440', '\u0434\u0435\u0446\u0435\u043c\u0431\u0430\u0440'],
  SHORTMONTHS: ['\u0458\u0430\u043d', '\u0444\u0435\u0431', '\u043c\u0430\u0440', '\u0430\u043f\u0440', '\u043c\u0430\u0458', '\u0458\u0443\u043d', '\u0458\u0443\u043b', '\u0430\u0432\u0433', '\u0441\u0435\u043f', '\u043e\u043a\u0442', '\u043d\u043e\u0432', '\u0434\u0435\u0446'],
  WEEKDAYS: ['\u043d\u0435\u0434\u0435\u0459\u0430', '\u043f\u043e\u043d\u0435\u0434\u0435\u0459\u0430\u043a', '\u0443\u0442\u043e\u0440\u0430\u043a', '\u0441\u0440\u0435\u0434\u0430', '\u0447\u0435\u0442\u0432\u0440\u0442\u0430\u043a', '\u043f\u0435\u0442\u0430\u043a', '\u0441\u0443\u0431\u043e\u0442\u0430'],
  SHORTWEEKDAYS: ['\u043d\u0435\u0434', '\u043f\u043e\u043d', '\u0443\u0442\u043e', '\u0441\u0440\u0435', '\u0447\u0435\u0442', '\u043f\u0435\u0442', '\u0441\u0443\u0431'],
  NARROWWEEKDAYS: ['\u043d', '\u043f', '\u0443', '\u0441', '\u0447', '\u043f', '\u0441'],
  SHORTQUARTERS: ['\u041a1', '\u041a2', '\u041a3', '\u041a4'],
  QUARTERS: ['\u041f\u0440\u0432\u043e \u0442\u0440\u043e\u043c\u0435\u0441\u0435\u0447\u0458\u0435', '\u0414\u0440\u0443\u0433\u043e \u0442\u0440\u043e\u043c\u0435\u0441\u0435\u0447\u0458\u0435', '\u0422\u0440\u0435\u045b\u0435 \u0442\u0440\u043e\u043c\u0435\u0441\u0435\u0447\u0458\u0435', '\u0427\u0435\u0442\u0432\u0440\u0442\u043e \u0442\u0440\u043e\u043c\u0435\u0441\u0435\u0447\u0458\u0435'],
  AMPMS: ['\u043f\u0440\u0435 \u043f\u043e\u0434\u043d\u0435', '\u043f\u043e\u043f\u043e\u0434\u043d\u0435'],
  DATEFORMATS: ['EEEE, dd. MMMM y.', 'dd. MMMM y.', 'dd.MM.y.', 'd.M.yy.'],
  TIMEFORMATS: ['HH.mm.ss zzzz', 'HH.mm.ss z', 'HH.mm.ss', 'HH.mm'],
  FIRSTDAYOFWEEK: 0,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 3
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
