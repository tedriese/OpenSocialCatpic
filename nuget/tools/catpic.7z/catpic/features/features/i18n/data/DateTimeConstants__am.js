/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['\u12d3/\u12d3', '\u12d3/\u121d'],
  ERANAMES: ['\u12d3/\u12d3', '\u12d3/\u121d'],
  NARROWMONTHS: ['\u1303', '\u134c', '\u121b', '\u12a4', '\u121c', '\u1301', '\u1301', '\u12a6', '\u1234', '\u12a6', '\u1296', '\u12f2'],
  MONTHS: ['\u1303\u1295\u12e9\u12c8\u122a', '\u134c\u1265\u1229\u12c8\u122a', '\u121b\u122d\u127d', '\u12a4\u1355\u1228\u120d', '\u121c\u12ed', '\u1301\u1295', '\u1301\u120b\u12ed', '\u12a6\u1308\u1235\u1275', '\u1234\u1355\u1274\u121d\u1260\u122d', '\u12a6\u12ad\u1270\u12cd\u1260\u122d', '\u1296\u126c\u121d\u1260\u122d', '\u12f2\u1234\u121d\u1260\u122d'],
  SHORTMONTHS: ['\u1303\u1295\u12e9', '\u134c\u1265\u1229', '\u121b\u122d\u127d', '\u12a4\u1355\u1228', '\u121c\u12ed', '\u1301\u1295', '\u1301\u120b\u12ed', '\u12a6\u1308\u1235', '\u1234\u1355\u1274', '\u12a6\u12ad\u1270', '\u1296\u126c\u121d', '\u12f2\u1234\u121d'],
  WEEKDAYS: ['\u12a5\u1211\u12f5', '\u1230\u129e', '\u121b\u12ad\u1230\u129e', '\u1228\u1261\u12d5', '\u1210\u1219\u1235', '\u12d3\u122d\u1265', '\u1245\u12f3\u121c'],
  SHORTWEEKDAYS: ['\u12a5\u1211\u12f5', '\u1230\u129e', '\u121b\u12ad\u1230', '\u1228\u1261\u12d5', '\u1210\u1219\u1235', '\u12d3\u122d\u1265', '\u1245\u12f3\u121c'],
  NARROWWEEKDAYS: ['\u12a5', '\u1230', '\u121b', '\u1228', '\u1210', '\u12d3', '\u1245'],
  SHORTQUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  QUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  AMPMS: ['\u1321\u12cb\u1275', '\u12a8\u1233\u12d3\u1275'],
  DATEFORMATS: ['EEEE\u1363 dd MMMM \u1240\u1295 y G', 'dd MMMM y', 'MMM d y', 'dd/MM/yy'],
  TIMEFORMATS: ['hh:mm:ss a zzzz', 'hh:mm:ss a z', 'h:mm:ss a', 'h:mm a'],
  FIRSTDAYOFWEEK: 5,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 1
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
