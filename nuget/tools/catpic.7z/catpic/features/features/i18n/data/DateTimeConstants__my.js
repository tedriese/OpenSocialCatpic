/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['\u1018\u102e\u1005\u102e', '\u1021\u1031\u1012\u102e'],
  ERANAMES: ['\u1001\u101b\u1005\u103a\u1010\u1031\u102c\u103a \u1019\u1015\u1031\u102b\u103a\u1019\u102e\u1000\u102c\u101c', '\u1001\u101b\u1005\u103a\u1010\u1031\u102c\u103a \u1015\u1031\u102b\u103a\u1011\u103d\u1014\u103a\u1038\u1015\u103c\u102e\u1038\u1000\u102c\u101c'],
  NARROWMONTHS: ['\u1007', '\u1016', '\u1019', '\u1027', '\u1019', '\u1007', '\u1007', '\u1029', '\u1005', '\u1021', '\u1014', '\u1012'],
  MONTHS: ['\u1007\u1014\u103a\u1014\u101d\u102b\u101b\u102e', '\u1016\u1031\u1016\u1031\u102c\u103a\u101d\u102b\u101b\u102e', '\u1019\u1010\u103a', '\u1027\u1015\u103c\u102e', '\u1019\u1031', '\u1007\u103d\u1014\u103a', '\u1007\u1030\u101c\u102d\u102f\u1004\u103a', '\u1029\u1002\u102f\u1010\u103a', '\u1005\u1000\u103a\u1010\u1004\u103a\u1018\u102c', '\u1021\u1031\u102c\u1000\u103a\u1010\u102d\u102f\u1018\u102c', '\u1014\u102d\u102f\u101d\u1004\u103a\u1018\u102c', '\u1012\u102e\u1007\u1004\u103a\u1018\u102c'],
  SHORTMONTHS: ['\u1007\u1014\u103a', '\u1016\u1031', '\u1019\u1010\u103a', '\u1027', '\u1019\u1031', '\u1007\u103d\u1014\u103a', '\u1007\u1030', '\u1029', '\u1005\u1000\u103a', '\u1021\u1031\u102c\u1000\u103a', '\u1014\u102d\u102f', '\u1012\u102e'],
  WEEKDAYS: ['\u1010\u1014\u1004\u103a\u1039\u1002\u1014\u103d\u1031', '\u1010\u1014\u1004\u103a\u1039\u101c\u102c', '\u1021\u1004\u103a\u1039\u1002\u102b', '\u1017\u102f\u1012\u1039\u1013\u101f\u1030\u1038', '\u1000\u103c\u102c\u101e\u1015\u1010\u1031\u1038', '\u101e\u1031\u102c\u1000\u103c\u102c', '\u1005\u1014\u1031'],
  SHORTWEEKDAYS: ['\u1014\u103d\u1031', '\u101c\u102c', '\u1002\u102b', '\u101f\u1030\u1038', '\u1010\u1031\u1038', '\u1000\u103c\u102c', '\u1014\u1031'],
  NARROWWEEKDAYS: ['\u1010', '\u1010', '\u1021', '\u1017', '\u1000', '\u101e', '\u1005'],
  SHORTQUARTERS: ['\u1015-\u1005\u102d\u1010\u103a', '\u1012\u102f-\u1005\u102d\u1010\u103a', '\u1010-\u1005\u102d\u1010\u103a', '\u1005-\u1005\u102d\u1010\u103a'],
  QUARTERS: ['\u1015\u1011\u1019 \u101e\u102f\u1036\u1038\u101c\u1015\u1010\u103a', '\u1012\u102f\u1010\u102d\u101a \u101e\u102f\u1036\u1038\u101c\u1015\u1010\u103a', '\u1010\u1010\u102d\u101a \u101e\u102f\u1036\u1038\u101c\u1015\u1010\u103a', '\u1005\u1010\u102f\u1010\u1039\u1011 \u101e\u102f\u1036\u1038\u101c\u1015\u1010\u103a'],
  AMPMS: ['\u1014\u1036\u1014\u1000\u103a', '\u100a\u1014\u1031'],
  DATEFORMATS: ['EEEE, y MMMM dd', 'y MMMM d', 'y MMM d', 'yy/MM/dd'],
  TIMEFORMATS: ['HH:mm:ss zzzz', 'HH:mm:ss z', 'HH:mm:ss', 'HH:mm'],
  FIRSTDAYOFWEEK: 0,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 3
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
