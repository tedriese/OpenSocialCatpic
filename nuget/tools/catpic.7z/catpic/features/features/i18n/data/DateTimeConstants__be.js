/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['\u0434\u0430 \u043d.\u0435.', '\u043d.\u0435.'],
  ERANAMES: ['\u0434\u0430 \u043d.\u044d.', '\u043d.\u044d.'],
  NARROWMONTHS: ['\u0441', '\u043b', '\u0441', '\u043a', '\u0442', '\u0447', '\u043b', '\u0436', '\u0432', '\u043a', '\u043b', '\u0441'],
  STANDALONENARROWMONTHS: ['\u0441', '\u043b', '\u0441', '\u043a', '\u043c', '\u0447', '\u043b', '\u0436', '\u0432', '\u043a', '\u043b', '\u0441'],
  MONTHS: ['\u0441\u0442\u0443\u0434\u0437\u0435\u043d\u044c', '\u043b\u044e\u0442\u044b', '\u0441\u0430\u043a\u0430\u0432\u0456\u043a', '\u043a\u0440\u0430\u0441\u0430\u0432\u0456\u043a', '\u043c\u0430\u0439', '\u0447\u044d\u0440\u0432\u0435\u043d\u044c', '\u043b\u0456\u043f\u0435\u043d\u044c', '\u0436\u043d\u0456\u0432\u0435\u043d\u044c', '\u0432\u0435\u0440\u0430\u0441\u0435\u043d\u044c', '\u043a\u0430\u0441\u0442\u0440\u044b\u0447\u043d\u0456\u043a', '\u043b\u0456\u0441\u0442\u0430\u043f\u0430\u0434', '\u0441\u043d\u0435\u0436\u0430\u043d\u044c'],
  STANDALONEMONTHS: ['\u0441\u0442\u0443\u0434\u0437\u0435\u043d\u044c', '\u043b\u044e\u0442\u044b', '\u0441\u0430\u043a\u0430\u0432\u0456\u043a', '\u043a\u0440\u0430\u0441\u0430\u0432\u0456\u043a', '\u0442\u0440\u0430\u0432\u0435\u043d\u044c', '\u0447\u044d\u0440\u0432\u0435\u043d\u044c', '\u043b\u0456\u043f\u0435\u043d\u044c', '\u0436\u043d\u0456\u0432\u0435\u043d\u044c', '\u0432\u0435\u0440\u0430\u0441\u0435\u043d\u044c', '\u043a\u0430\u0441\u0442\u0440\u044b\u0447\u043d\u0456\u043a', '\u043b\u0456\u0441\u0442\u0430\u043f\u0430\u0434', '\u0441\u043d\u0435\u0436\u0430\u043d\u044c'],
  SHORTMONTHS: ['\u0441\u0442\u0443', '\u043b\u044e\u0442', '\u0441\u0430\u043a', '\u043a\u0440\u0430', '\u043c\u0430\u0439', '\u0447\u044d\u0440', '\u043b\u0456\u043f', '\u0436\u043d\u0456', '\u0432\u0435\u0440', '\u043a\u0430\u0441', '\u043b\u0456\u0441', '\u0441\u043d\u0435'],
  STANDALONESHORTMONTHS: ['\u0441\u0442\u0443', '\u043b\u044e\u0442', '\u0441\u0430\u043a', '\u043a\u0440\u0430', '\u0442\u0440\u0430', '\u0447\u044d\u0440', '\u043b\u0456\u043f', '\u0436\u043d\u0456', '\u0432\u0435\u0440', '\u043a\u0430\u0441', '\u043b\u0456\u0441', '\u0441\u043d\u0435'],
  WEEKDAYS: ['\u043d\u044f\u0434\u0437\u0435\u043b\u044f', '\u043f\u0430\u043d\u044f\u0434\u0437\u0435\u043b\u0430\u043a', '\u0430\u045e\u0442\u043e\u0440\u0430\u043a', '\u0441\u0435\u0440\u0430\u0434\u0430', '\u0447\u0430\u0446\u0432\u0435\u0440', '\u043f\u044f\u0442\u043d\u0456\u0446\u0430', '\u0441\u0443\u0431\u043e\u0442\u0430'],
  SHORTWEEKDAYS: ['\u043d\u0434', '\u043f\u043d', '\u0430\u045e', '\u0441\u0440', '\u0447\u0446', '\u043f\u0442', '\u0441\u0431'],
  NARROWWEEKDAYS: ['\u043d', '\u043f', '\u0430', '\u0441', '\u0447', '\u043f', '\u0441'],
  SHORTQUARTERS: ['1-\u0448\u044b \u043a\u0432.', '2-\u0433\u0456 \u043a\u0432.', '3-\u0446\u0456 \u043a\u0432.', '4-\u0442\u044b \u043a\u0432.'],
  QUARTERS: ['1-\u0448\u044b \u043a\u0432\u0430\u0440\u0442\u0430\u043b', '2-\u0433\u0456 \u043a\u0432\u0430\u0440\u0442\u0430\u043b', '3-\u0446\u0456 \u043a\u0432\u0430\u0440\u0442\u0430\u043b', '4-\u0442\u044b \u043a\u0432\u0430\u0440\u0442\u0430\u043b'],
  AMPMS: ['\u0434\u0430 \u043f\u0430\u043b\u0443\u0434\u043d\u044f', '\u043f\u0430\u0441\u043b\u044f \u043f\u0430\u043b\u0443\u0434\u043d\u044f'],
  DATEFORMATS: ['EEEE, d MMMM y', 'd MMMM y', 'd.M.yyyy', 'd.M.yy'],
  TIMEFORMATS: ['HH.mm.ss zzzz', 'HH.mm.ss z', 'HH.mm.ss', 'HH.mm'],
  FIRSTDAYOFWEEK: 0,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 3
};
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
