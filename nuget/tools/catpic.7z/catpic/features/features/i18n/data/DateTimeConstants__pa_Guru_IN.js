/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['BCE', 'CE'],
  ERANAMES: ['\u0a08\u0a38\u0a3e\u0a2a\u0a42\u0a30\u0a35', '\u0a38\u0a70\u0a28'],
  NARROWMONTHS: ['\u0a1c', '\u0a2b', '\u0a2e\u0a3e', '\u0a05', '\u0a2e', '\u0a1c\u0a42', '\u0a1c\u0a41', '\u0a05', '\u0a38', '\u0a05', '\u0a28', '\u0a26'],
  MONTHS: ['\u0a1c\u0a28\u0a35\u0a30\u0a40', '\u0a2b\u0a3c\u0a30\u0a35\u0a30\u0a40', '\u0a2e\u0a3e\u0a30\u0a1a', '\u0a05\u0a2a\u0a4d\u0a30\u0a48\u0a32', '\u0a2e\u0a08', '\u0a1c\u0a42\u0a28', '\u0a1c\u0a41\u0a32\u0a3e\u0a08', '\u0a05\u0a17\u0a38\u0a24', '\u0a38\u0a24\u0a70\u0a2c\u0a30', '\u0a05\u0a15\u0a24\u0a42\u0a2c\u0a30', '\u0a28\u0a35\u0a70\u0a2c\u0a30', '\u0a26\u0a38\u0a70\u0a2c\u0a30'],
  SHORTMONTHS: ['\u0a1c\u0a28\u0a35\u0a30\u0a40', '\u0a2b\u0a3c\u0a30\u0a35\u0a30\u0a40', '\u0a2e\u0a3e\u0a30\u0a1a', '\u0a05\u0a2a\u0a4d\u0a30\u0a48\u0a32', '\u0a2e\u0a08', '\u0a1c\u0a42\u0a28', '\u0a1c\u0a41\u0a32\u0a3e\u0a08', '\u0a05\u0a17\u0a38\u0a24', '\u0a38\u0a24\u0a70\u0a2c\u0a30', '\u0a05\u0a15\u0a24\u0a42\u0a2c\u0a30', '\u0a28\u0a35\u0a70\u0a2c\u0a30', '\u0a26\u0a38\u0a70\u0a2c\u0a30'],
  WEEKDAYS: ['\u0a10\u0a24\u0a35\u0a3e\u0a30', '\u0a38\u0a4b\u0a2e\u0a35\u0a3e\u0a30', '\u0a2e\u0a70\u0a17\u0a32\u0a35\u0a3e\u0a30', '\u0a2c\u0a41\u0a27\u0a35\u0a3e\u0a30', '\u0a35\u0a40\u0a30\u0a35\u0a3e\u0a30', '\u0a38\u0a3c\u0a41\u0a71\u0a15\u0a30\u0a35\u0a3e\u0a30', '\u0a38\u0a3c\u0a28\u0a40\u0a1a\u0a30\u0a35\u0a3e\u0a30'],
  SHORTWEEKDAYS: ['\u0a10\u0a24.', '\u0a38\u0a4b\u0a2e.', '\u0a2e\u0a70\u0a17\u0a32.', '\u0a2c\u0a41\u0a27.', '\u0a35\u0a40\u0a30.', '\u0a38\u0a3c\u0a41\u0a15\u0a30.', '\u0a38\u0a3c\u0a28\u0a40.'],
  NARROWWEEKDAYS: ['\u0a10', '\u0a38\u0a4b', '\u0a2e\u0a70', '\u0a2c\u0a41\u0a71', '\u0a35\u0a40', '\u0a38\u0a3c\u0a41\u0a71', '\u0a38\u0a3c'],
  SHORTQUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  QUARTERS: ['\u0a2a\u0a39\u0a3f\u0a32\u0a3e\u0a02 \u0a1a\u0a4c\u0a25\u0a3e\u0a08', '\u0a26\u0a42\u0a1c\u0a3e \u0a1a\u0a4c\u0a25\u0a3e\u0a08', '\u0a24\u0a40\u0a1c\u0a3e \u0a1a\u0a4c\u0a25\u0a3e\u0a08', '\u0a1a\u0a4c\u0a25\u0a3e \u0a1a\u0a4c\u0a25\u0a3e\u0a08'],
  AMPMS: ['\u0a38\u0a35\u0a47\u0a30\u0a47', '\u0a38\u0a3c\u0a3e\u0a2e'],
  DATEFORMATS: ['EEEE, dd MMMM y', 'd MMMM y', 'd MMM y', 'dd/MM/yyyy'],
  TIMEFORMATS: ['h:mm:ss a zzzz', 'h:mm:ss a z', 'h:mm:ss a', 'h:mm a'],
  FIRSTDAYOFWEEK: 6,
  WEEKENDRANGE: [6, 6],
  FIRSTWEEKCUTOFFDAY: 2
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
