/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['BCE', 'CE'],
  ERANAMES: ['BCE', 'CE'],
  NARROWMONTHS: ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'],
  MONTHS: ['\u049b\u0430\u04a3\u0442\u0430\u0440', '\u0430\u049b\u043f\u0430\u043d', '\u043d\u0430\u0443\u0440\u044b\u0437', '\u0441\u04d9\u0443\u0456\u0440', '\u043c\u0430\u043c\u044b\u0440', '\u043c\u0430\u0443\u0441\u044b\u043c', '\u0448\u0456\u043b\u0434\u0435', '\u0442\u0430\u043c\u044b\u0437', '\u049b\u044b\u0440\u043a\u04af\u0439\u0435\u043a', '\u049b\u0430\u0437\u0430\u043d', '\u049b\u0430\u0440\u0430\u0448\u0430', '\u0436\u0435\u043b\u0442\u043e\u049b\u0441\u0430\u043d'],
  SHORTMONTHS: ['\u049b\u0430\u04a3.', '\u0430\u049b\u043f.', '\u043d\u0430\u0443.', '\u0441\u04d9\u0443.', '\u043c\u0430\u043c.', '\u043c\u0430\u0443.', '\u0448\u0456\u043b.', '\u0442\u0430\u043c.', '\u049b\u044b\u0440.', '\u049b\u0430\u0437.', '\u049b\u0430\u0440.', '\u0436\u0435\u043b\u0442.'],
  WEEKDAYS: ['\u0436\u0435\u043a\u0441\u0435\u043d\u0456', '\u0434\u0443\u0439\u0441\u0435\u043d\u0431\u0456', '\u0441\u0435\u0439\u0441\u0435\u043d\u0431\u0456', '\u0441\u04d9\u0440\u0435\u043d\u0431\u0456', '\u0431\u0435\u0439\u0441\u0435\u043d\u0431\u0456', '\u0436\u04b1\u043c\u0430', '\u0441\u0435\u043d\u0431\u0456'],
  SHORTWEEKDAYS: ['\u0436\u0441.', '\u0434\u0441.', '\u0441\u0441.', '\u0441\u0440.', '\u0431\u0441.', '\u0436\u043c.', '\u0441\u04bb.'],
  NARROWWEEKDAYS: ['1', '2', '3', '4', '5', '6', '7'],
  SHORTQUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  QUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  AMPMS: ['AM', 'PM'],
  DATEFORMATS: ["EEEE, d MMMM y '\u0436'.", "d MMMM y '\u0436'.", 'dd.MM.yyyy', 'dd.MM.yy'],
  TIMEFORMATS: ['HH:mm:ss zzzz', 'HH:mm:ss z', 'HH:mm:ss', 'HH:mm'],
  FIRSTDAYOFWEEK: 0,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 3
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
