/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['BCE', 'CE'],
  ERANAMES: ['BCE', 'CE'],
  NARROWMONTHS: ['\u0b1c\u0b3e', '\u0b2b\u0b47', '\u0b2e\u0b3e', '\u0b05', '\u0b2e\u0b47', '\u0b1c\u0b41', '\u0b1c\u0b41', '\u0b05', '\u0b38\u0b47', '\u0b05', '\u0b28', '\u0b21\u0b3f'],
  MONTHS: ['\u0b1c\u0b3e\u0b28\u0b41\u0b06\u0b30\u0b40', '\u0b2b\u0b47\u0b2c\u0b4d\u0b30\u0b41\u0b5f\u0b3e\u0b30\u0b40', '\u0b2e\u0b3e\u0b30\u0b4d\u0b1a\u0b4d\u0b1a', '\u0b05\u0b2a\u0b4d\u0b30\u0b47\u0b32', '\u0b2e\u0b47', '\u0b1c\u0b41\u0b28', '\u0b1c\u0b41\u0b32\u0b3e\u0b07', '\u0b05\u0b17\u0b37\u0b4d\u0b1f', '\u0b38\u0b47\u0b2a\u0b4d\u0b1f\u0b47\u0b2e\u0b4d\u0b2c\u0b30', '\u0b05\u0b15\u0b4d\u0b1f\u0b4b\u0b2c\u0b30', '\u0b28\u0b2d\u0b47\u0b2e\u0b4d\u0b2c\u0b30', '\u0b21\u0b3f\u0b38\u0b47\u0b2e\u0b4d\u0b2c\u0b30'],
  SHORTMONTHS: ['\u0b1c\u0b3e\u0b28\u0b41\u0b06\u0b30\u0b40', '\u0b2b\u0b47\u0b2c\u0b4d\u0b30\u0b41\u0b5f\u0b3e\u0b30\u0b40', '\u0b2e\u0b3e\u0b30\u0b4d\u0b1a\u0b4d\u0b1a', '\u0b05\u0b2a\u0b4d\u0b30\u0b47\u0b32', '\u0b2e\u0b47', '\u0b1c\u0b41\u0b28', '\u0b1c\u0b41\u0b32\u0b3e\u0b07', '\u0b05\u0b17\u0b37\u0b4d\u0b1f', '\u0b38\u0b47\u0b2a\u0b4d\u0b1f\u0b47\u0b2e\u0b4d\u0b2c\u0b30', '\u0b05\u0b15\u0b4d\u0b1f\u0b4b\u0b2c\u0b30', '\u0b28\u0b2d\u0b47\u0b2e\u0b4d\u0b2c\u0b30', '\u0b21\u0b3f\u0b38\u0b47\u0b2e\u0b4d\u0b2c\u0b30'],
  WEEKDAYS: ['\u0b30\u0b2c\u0b3f\u0b2c\u0b3e\u0b30', '\u0b38\u0b4b\u0b2e\u0b2c\u0b3e\u0b30', '\u0b2e\u0b19\u0b4d\u0b17\u0b33\u0b2c\u0b3e\u0b30', '\u0b2c\u0b41\u0b27\u0b2c\u0b3e\u0b30', '\u0b17\u0b41\u0b30\u0b41\u0b2c\u0b3e\u0b30', '\u0b36\u0b41\u0b15\u0b4d\u0b30\u0b2c\u0b3e\u0b30', '\u0b36\u0b28\u0b3f\u0b2c\u0b3e\u0b30'],
  SHORTWEEKDAYS: ['\u0b30\u0b2c\u0b3f', '\u0b38\u0b4b\u0b2e', '\u0b2e\u0b19\u0b4d\u0b17\u0b33', '\u0b2c\u0b41\u0b27', '\u0b17\u0b41\u0b30\u0b41', '\u0b36\u0b41\u0b15\u0b4d\u0b30', '\u0b36\u0b28\u0b3f'],
  NARROWWEEKDAYS: ['\u0b30', '\u0b38\u0b4b', '\u0b2e', '\u0b2c\u0b41', '\u0b17\u0b41', '\u0b36\u0b41', '\u0b36'],
  SHORTQUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  QUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  AMPMS: ['am', 'pm'],
  DATEFORMATS: ['EEEE, d MMMM y', 'd MMMM y', 'd MMM y', 'd-M-yy'],
  TIMEFORMATS: ['h:mm:ss a zzzz', 'h:mm:ss a z', 'h:mm:ss a', 'h:mm a'],
  FIRSTDAYOFWEEK: 6,
  WEEKENDRANGE: [6, 6],
  FIRSTWEEKCUTOFFDAY: 2
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
