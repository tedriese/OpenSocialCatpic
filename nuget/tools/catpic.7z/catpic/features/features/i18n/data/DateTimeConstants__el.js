/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['\u03c0.\u03a7.', '\u03bc.\u03a7.'],
  ERANAMES: ['\u03c0.\u03a7.', '\u03bc.\u03a7.'],
  NARROWMONTHS: ['\u0399', '\u03a6', '\u039c', '\u0391', '\u039c', '\u0399', '\u0399', '\u0391', '\u03a3', '\u039f', '\u039d', '\u0394'],
  MONTHS: ['\u0399\u03b1\u03bd\u03bf\u03c5\u03b1\u03c1\u03af\u03bf\u03c5', '\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03b1\u03c1\u03af\u03bf\u03c5', '\u039c\u03b1\u03c1\u03c4\u03af\u03bf\u03c5', '\u0391\u03c0\u03c1\u03b9\u03bb\u03af\u03bf\u03c5', '\u039c\u03b1\u0390\u03bf\u03c5', '\u0399\u03bf\u03c5\u03bd\u03af\u03bf\u03c5', '\u0399\u03bf\u03c5\u03bb\u03af\u03bf\u03c5', '\u0391\u03c5\u03b3\u03bf\u03cd\u03c3\u03c4\u03bf\u03c5', '\u03a3\u03b5\u03c0\u03c4\u03b5\u03bc\u03b2\u03c1\u03af\u03bf\u03c5', '\u039f\u03ba\u03c4\u03c9\u03b2\u03c1\u03af\u03bf\u03c5', '\u039d\u03bf\u03b5\u03bc\u03b2\u03c1\u03af\u03bf\u03c5', '\u0394\u03b5\u03ba\u03b5\u03bc\u03b2\u03c1\u03af\u03bf\u03c5'],
  STANDALONEMONTHS: ['\u0399\u03b1\u03bd\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2', '\u03a6\u03b5\u03b2\u03c1\u03bf\u03c5\u03ac\u03c1\u03b9\u03bf\u03c2', '\u039c\u03ac\u03c1\u03c4\u03b9\u03bf\u03c2', '\u0391\u03c0\u03c1\u03af\u03bb\u03b9\u03bf\u03c2', '\u039c\u03ac\u03b9\u03bf\u03c2', '\u0399\u03bf\u03cd\u03bd\u03b9\u03bf\u03c2', '\u0399\u03bf\u03cd\u03bb\u03b9\u03bf\u03c2', '\u0391\u03cd\u03b3\u03bf\u03c5\u03c3\u03c4\u03bf\u03c2', '\u03a3\u03b5\u03c0\u03c4\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2', '\u039f\u03ba\u03c4\u03ce\u03b2\u03c1\u03b9\u03bf\u03c2', '\u039d\u03bf\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2', '\u0394\u03b5\u03ba\u03ad\u03bc\u03b2\u03c1\u03b9\u03bf\u03c2'],
  SHORTMONTHS: ['\u0399\u03b1\u03bd', '\u03a6\u03b5\u03b2', '\u039c\u03b1\u03c1', '\u0391\u03c0\u03c1', '\u039c\u03b1\u03ca', '\u0399\u03bf\u03c5\u03bd', '\u0399\u03bf\u03c5\u03bb', '\u0391\u03c5\u03b3', '\u03a3\u03b5\u03c0', '\u039f\u03ba\u03c4', '\u039d\u03bf\u03b5', '\u0394\u03b5\u03ba'],
  WEEKDAYS: ['\u039a\u03c5\u03c1\u03b9\u03b1\u03ba\u03ae', '\u0394\u03b5\u03c5\u03c4\u03ad\u03c1\u03b1', '\u03a4\u03c1\u03af\u03c4\u03b7', '\u03a4\u03b5\u03c4\u03ac\u03c1\u03c4\u03b7', '\u03a0\u03ad\u03bc\u03c0\u03c4\u03b7', '\u03a0\u03b1\u03c1\u03b1\u03c3\u03ba\u03b5\u03c5\u03ae', '\u03a3\u03ac\u03b2\u03b2\u03b1\u03c4\u03bf'],
  SHORTWEEKDAYS: ['\u039a\u03c5\u03c1', '\u0394\u03b5\u03c5', '\u03a4\u03c1\u03b9', '\u03a4\u03b5\u03c4', '\u03a0\u03b5\u03bc', '\u03a0\u03b1\u03c1', '\u03a3\u03b1\u03b2'],
  NARROWWEEKDAYS: ['\u039a', '\u0394', '\u03a4', '\u03a4', '\u03a0', '\u03a0', '\u03a3'],
  SHORTQUARTERS: ['\u03a41', '\u03a42', '\u03a43', '\u03a44'],
  QUARTERS: ['1\u03bf \u03c4\u03c1\u03af\u03bc\u03b7\u03bd\u03bf', '2\u03bf \u03c4\u03c1\u03af\u03bc\u03b7\u03bd\u03bf', '3\u03bf \u03c4\u03c1\u03af\u03bc\u03b7\u03bd\u03bf', '4\u03bf \u03c4\u03c1\u03af\u03bc\u03b7\u03bd\u03bf'],
  AMPMS: ['\u03c0.\u03bc.', '\u03bc.\u03bc.'],
  DATEFORMATS: ['EEEE, dd MMMM y', 'dd MMMM y', 'dd MMM y', 'dd/MM/yyyy'],
  TIMEFORMATS: ['h:mm:ss a zzzz', 'h:mm:ss a z', 'h:mm:ss a', 'h:mm a'],
  FIRSTDAYOFWEEK: 0,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 3
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
