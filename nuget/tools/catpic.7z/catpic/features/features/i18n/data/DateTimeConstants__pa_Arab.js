/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['BCE', 'CE'],
  ERANAMES: ['\u0627\u064a\u0633\u0627\u067e\u0648\u0631\u0648', '\u0633\u06ba'],
  NARROWMONTHS: ['\u0a1c', '\u0a2b', '\u0a2e\u0a3e', '\u0a05', '\u0a2e', '\u0a1c\u0a42', '\u0a1c\u0a41', '\u0a05', '\u0a38', '\u0a05', '\u0a28', '\u0a26'],
  MONTHS: ['\u062c\u0646\u0648\u0631\u06cc', '\u0641\u0631\u0648\u0631\u06cc', '\u0645\u0627\u0631\u0686', '\u0627\u067e\u0631\u06cc\u0644', '\u0645\u0626', '\u062c\u0648\u0646', '\u062c\u0648\u0644\u0627\u0626\u06cc', '\u0627\u06af\u0633\u062a', '\u0633\u062a\u0645\u0628\u0631', '\u0627\u06a9\u062a\u0648\u0628\u0631', '\u0646\u0648\u0645\u0628\u0631', '\u062f\u0633\u0645\u0628\u0631'],
  SHORTMONTHS: ['\u062c\u0646\u0648\u0631\u06cc', '\u0641\u0631\u0648\u0631\u06cc', '\u0645\u0627\u0631\u0686', '\u0627\u067e\u0631\u06cc\u0644', '\u0645\u0626', '\u062c\u0648\u0646', '\u062c\u0648\u0644\u0627\u0626\u06cc', '\u0627\u06af\u0633\u062a', '\u0633\u062a\u0645\u0628\u0631', '\u0627\u06a9\u062a\u0648\u0628\u0631', '\u0646\u0648\u0645\u0628\u0631', '\u062f\u0633\u0645\u0628\u0631'],
  WEEKDAYS: ['\u0627\u062a\u0648\u0627\u0631', '\u067e\u06cc\u0631', '\u0645\u0646\u06af\u0644', '\u0628\u064f\u062f\u06be', '\u062c\u0645\u0639\u0631\u0627\u062a', '\u062c\u0645\u0639\u06c1', '\u06c1\u0641\u062a\u06c1'],
  SHORTWEEKDAYS: ['\u0a10\u0a24.', '\u0a38\u0a4b\u0a2e.', '\u0a2e\u0a70\u0a17\u0a32.', '\u0a2c\u0a41\u0a27.', '\u0a35\u0a40\u0a30.', '\u0a38\u0a3c\u0a41\u0a15\u0a30.', '\u0a38\u0a3c\u0a28\u0a40.'],
  NARROWWEEKDAYS: ['\u0a10', '\u0a38\u0a4b', '\u0a2e\u0a70', '\u0a2c\u0a41\u0a71', '\u0a35\u0a40', '\u0a38\u0a3c\u0a41\u0a71', '\u0a38\u0a3c'],
  SHORTQUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  QUARTERS: ['\u0686\u0648\u062a\u06be\u0627\u064a \u067e\u06c1\u0644\u0627\u06ba', '\u0686\u0648\u062a\u06be\u0627\u064a \u062f\u0648\u062c\u0627', '\u0686\u0648\u062a\u06be\u0627\u064a \u062a\u064a\u062c\u0627', '\u0686\u0648\u062a\u06be\u0627\u064a \u0686\u0648\u062a\u06be\u0627'],
  AMPMS: ['\u0a38\u0a35\u0a47\u0a30\u0a47', '\u0a38\u0a3c\u0a3e\u0a2e'],
  DATEFORMATS: ['EEEE, dd MMMM y', 'd MMMM y', 'd MMM y', 'dd/MM/yyyy'],
  TIMEFORMATS: ['h:mm:ss a zzzz', 'h:mm:ss a z', 'h:mm:ss a', 'h:mm a'],
  FIRSTDAYOFWEEK: 0,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 3
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
