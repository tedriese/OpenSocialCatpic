/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['\u10e9\u10d5\u10d4\u10dc\u10e1 \u10ec\u10d4\u10da\u10d7\u10d0\u10e6\u10e0\u10d8\u10ea\u10ee\u10d5\u10d0\u10db\u10d3\u10d4', '\u10e9\u10d5\u10d4\u10dc\u10d8 \u10ec\u10d4\u10da\u10d7\u10d0\u10e6\u10e0\u10d8\u10ea\u10ee\u10d5\u10d8\u10d7'],
  ERANAMES: ['\u10e9\u10d5\u10d4\u10dc\u10e1 \u10ec\u10d4\u10da\u10d7\u10d0\u10e6\u10e0\u10d8\u10ea\u10ee\u10d5\u10d0\u10db\u10d3\u10d4', '\u10e9\u10d5\u10d4\u10dc\u10d8 \u10ec\u10d4\u10da\u10d7\u10d0\u10e6\u10e0\u10d8\u10ea\u10ee\u10d5\u10d8\u10d7'],
  NARROWMONTHS: ['\u10d8', '\u10d7', '\u10db', '\u10d0', '\u10db', '\u10d8', '\u10d8', '\u10d0', '\u10e1', '\u10dd', '\u10dc', '\u10d3'],
  MONTHS: ['\u10d8\u10d0\u10dc\u10d5\u10d0\u10e0\u10d8', '\u10d7\u10d4\u10d1\u10d4\u10e0\u10d5\u10d0\u10da\u10d8', '\u10db\u10d0\u10e0\u10e2\u10d8', '\u10d0\u10de\u10e0\u10d8\u10da\u10d8', '\u10db\u10d0\u10d8\u10e1\u10d8', '\u10d8\u10d5\u10dc\u10d8\u10e1\u10d8', '\u10d8\u10d5\u10da\u10d8\u10e1\u10d8', '\u10d0\u10d2\u10d5\u10d8\u10e1\u10e2\u10dd', '\u10e1\u10d4\u10e5\u10e2\u10d4\u10db\u10d1\u10d4\u10e0\u10d8', '\u10dd\u10e5\u10e2\u10dd\u10db\u10d1\u10d4\u10e0\u10d8', '\u10dc\u10dd\u10d4\u10db\u10d1\u10d4\u10e0\u10d8', '\u10d3\u10d4\u10d9\u10d4\u10db\u10d1\u10d4\u10e0\u10d8'],
  SHORTMONTHS: ['\u10d8\u10d0\u10dc', '\u10d7\u10d4\u10d1', '\u10db\u10d0\u10e0', '\u10d0\u10de\u10e0', '\u10db\u10d0\u10d8', '\u10d8\u10d5\u10dc', '\u10d8\u10d5\u10da', '\u10d0\u10d2\u10d5', '\u10e1\u10d4\u10e5', '\u10dd\u10e5\u10e2', '\u10dc\u10dd\u10d4', '\u10d3\u10d4\u10d9'],
  WEEKDAYS: ['\u10d9\u10d5\u10d8\u10e0\u10d0', '\u10dd\u10e0\u10e8\u10d0\u10d1\u10d0\u10d7\u10d8', '\u10e1\u10d0\u10db\u10e8\u10d0\u10d1\u10d0\u10d7\u10d8', '\u10dd\u10d7\u10ee\u10e8\u10d0\u10d1\u10d0\u10d7\u10d8', '\u10ee\u10e3\u10d7\u10e8\u10d0\u10d1\u10d0\u10d7\u10d8', '\u10de\u10d0\u10e0\u10d0\u10e1\u10d9\u10d4\u10d5\u10d8', '\u10e8\u10d0\u10d1\u10d0\u10d7\u10d8'],
  SHORTWEEKDAYS: ['\u10d9\u10d5\u10d8', '\u10dd\u10e0\u10e8', '\u10e1\u10d0\u10db', '\u10dd\u10d7\u10ee', '\u10ee\u10e3\u10d7', '\u10de\u10d0\u10e0', '\u10e8\u10d0\u10d1'],
  NARROWWEEKDAYS: ['\u10d9', '\u10dd', '\u10e1', '\u10dd', '\u10ee', '\u10de', '\u10e8'],
  SHORTQUARTERS: ['I \u10d9\u10d5.', 'II \u10d9\u10d5.', 'III \u10d9\u10d5.', 'IV \u10d9\u10d5.'],
  QUARTERS: ['1-\u10da\u10d8 \u10d9\u10d5\u10d0\u10e0\u10e2\u10d0\u10da\u10d8', '\u10db\u10d4-2 \u10d9\u10d5\u10d0\u10e0\u10e2\u10d0\u10da\u10d8', '\u10db\u10d4-3 \u10d9\u10d5\u10d0\u10e0\u10e2\u10d0\u10da\u10d8', '\u10db\u10d4-4 \u10d9\u10d5\u10d0\u10e0\u10e2\u10d0\u10da\u10d8'],
  AMPMS: ['\u10d3\u10d8\u10da\u10d8\u10e1', '\u10e1\u10d0\u10e6\u10d0\u10db\u10dd\u10e1'],
  DATEFORMATS: ['EEEE, y MMMM dd', 'y MMMM d', 'y MMM d', 'yy/MM/dd'],
  TIMEFORMATS: ['HH:mm:ss zzzz', 'HH:mm:ss z', 'HH:mm:ss', 'HH:mm'],
  FIRSTDAYOFWEEK: 6,
  WEEKENDRANGE: [5, 6],
  FIRSTWEEKCUTOFFDAY: 2
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
