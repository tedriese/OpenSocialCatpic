/*
 * Licensed to the Apache Software Foundation (ASF) under one
 * or more contributor license agreements. See the NOTICE file
 * distributed with this work for additional information
 * regarding copyright ownership. The ASF licenses this file
 * to you under the Apache License, Version 2.0 (the
 * "License"); you may not use this file except in compliance
 * with the License. You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on an
 * "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations under the License.
 */


gadgets.i18n = gadgets.i18n || {};

gadgets.i18n.DateTimeConstants = {
  ERAS: ['BCE', 'CE'],
  ERANAMES: ['\u0c08\u0c38\u0c3e\u0c2a\u0c42\u0c30\u0c4d\u0c35.', '\u0c38\u0c28\u0c4d.'],
  NARROWMONTHS: ['\u0c1c', '\u0c2b\u0c3f', '\u0c2e', '\u0c0e', '\u0c2e\u0c46', '\u0c1c\u0c41', '\u0c1c\u0c41', '\u0c06', '\u0c38\u0c46', '\u0c05', '\u0c28', '\u0c21\u0c3f'],
  MONTHS: ['\u0c1c\u0c28\u0c35\u0c30\u0c3f', '\u0c2b\u0c3f\u0c2c\u0c4d\u0c30\u0c35\u0c30\u0c3f', '\u0c2e\u0c3e\u0c30\u0c4d\u0c1a\u0c3f', '\u0c0f\u0c2a\u0c4d\u0c30\u0c3f\u0c32\u0c4d', '\u0c2e\u0c47', '\u0c1c\u0c42\u0c28\u0c4d', '\u0c1c\u0c42\u0c32\u0c48', '\u0c06\u0c17\u0c38\u0c4d\u0c1f\u0c41', '\u0c38\u0c46\u0c2a\u0c4d\u0c1f\u0c46\u0c02\u0c2c\u0c30\u0c4d', '\u0c05\u0c15\u0c4d\u0c1f\u0c4b\u0c2c\u0c30\u0c4d', '\u0c28\u0c35\u0c02\u0c2c\u0c30\u0c4d', '\u0c21\u0c3f\u0c38\u0c46\u0c02\u0c2c\u0c30\u0c4d'],
  SHORTMONTHS: ['\u0c1c\u0c28\u0c35\u0c30\u0c3f', '\u0c2b\u0c3f\u0c2c\u0c4d\u0c30\u0c35\u0c30\u0c3f', '\u0c2e\u0c3e\u0c30\u0c4d\u0c1a\u0c3f', '\u0c0f\u0c2a\u0c4d\u0c30\u0c3f\u0c32\u0c4d', '\u0c2e\u0c47', '\u0c1c\u0c42\u0c28\u0c4d', '\u0c1c\u0c42\u0c32\u0c48', '\u0c06\u0c17\u0c38\u0c4d\u0c1f\u0c41', '\u0c38\u0c46\u0c2a\u0c4d\u0c1f\u0c46\u0c02\u0c2c\u0c30\u0c4d', '\u0c05\u0c15\u0c4d\u0c1f\u0c4b\u0c2c\u0c30\u0c4d', '\u0c28\u0c35\u0c02\u0c2c\u0c30\u0c4d', '\u0c21\u0c3f\u0c38\u0c46\u0c02\u0c2c\u0c30\u0c4d'],
  WEEKDAYS: ['\u0c06\u0c26\u0c3f\u0c35\u0c3e\u0c30\u0c02', '\u0c38\u0c4b\u0c2e\u0c35\u0c3e\u0c30\u0c02', '\u0c2e\u0c02\u0c17\u0c33\u0c35\u0c3e\u0c30\u0c02', '\u0c2c\u0c41\u0c27\u0c35\u0c3e\u0c30\u0c02', '\u0c17\u0c41\u0c30\u0c41\u0c35\u0c3e\u0c30\u0c02', '\u0c36\u0c41\u0c15\u0c4d\u0c30\u0c35\u0c3e\u0c30\u0c02', '\u0c36\u0c28\u0c3f\u0c35\u0c3e\u0c30\u0c02'],
  SHORTWEEKDAYS: ['\u0c06\u0c26\u0c3f', '\u0c38\u0c4b\u0c2e', '\u0c2e\u0c02\u0c17\u0c33', '\u0c2c\u0c41\u0c27', '\u0c17\u0c41\u0c30\u0c41', '\u0c36\u0c41\u0c15\u0c4d\u0c30', '\u0c36\u0c28\u0c3f'],
  NARROWWEEKDAYS: ['\u0c06', '\u0c38\u0c4b', '\u0c2e', '\u0c2d\u0c41', '\u0c17\u0c41', '\u0c36\u0c41', '\u0c36'],
  SHORTQUARTERS: ['Q1', 'Q2', 'Q3', 'Q4'],
  QUARTERS: ['\u0c12\u0c15\u0c1f\u0c3f 1', '\u0c30\u0c46\u0c02\u0c21\u0c41 2', '\u0c2e\u0c42\u0c21\u0c41 3', '\u0c28\u0c3e\u0c32\u0c41\u0c17\u0c41 4'],
  AMPMS: ['am', 'pm'],
  DATEFORMATS: ['EEEE d MMMM y', 'd MMMM y', 'd MMM y', 'dd-MM-yy'],
  TIMEFORMATS: ['h:mm:ss a zzzz', 'h:mm:ss a z', 'h:mm:ss a', 'h:mm a'],
  FIRSTDAYOFWEEK: 6,
  WEEKENDRANGE: [6, 6],
  FIRSTWEEKCUTOFFDAY: 2
};
gadgets.i18n.DateTimeConstants.STANDALONENARROWMONTHS = gadgets.i18n.DateTimeConstants.NARROWMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEMONTHS = gadgets.i18n.DateTimeConstants.MONTHS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTMONTHS = gadgets.i18n.DateTimeConstants.SHORTMONTHS;
gadgets.i18n.DateTimeConstants.STANDALONEWEEKDAYS = gadgets.i18n.DateTimeConstants.WEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONESHORTWEEKDAYS = gadgets.i18n.DateTimeConstants.SHORTWEEKDAYS;
gadgets.i18n.DateTimeConstants.STANDALONENARROWWEEKDAYS = gadgets.i18n.DateTimeConstants.NARROWWEEKDAYS;
